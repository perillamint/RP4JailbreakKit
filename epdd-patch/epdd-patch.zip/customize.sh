# Set epdd permission to 0755
set_perm $MODPATH/system/bin/epdd 0 0 0755
